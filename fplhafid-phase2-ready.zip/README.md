# FPLHafid — Phase 2

نسخة عربية RTL من FPLHafid مع تكامل مباشر مع بيانات FPL العامة.

## التشغيل
1. ثبّت Node.js (يفضل إصدار LTS حديث).
2. افتح هذا المجلد في VS Code.
3. في Terminal:
   `npm install`
4. ثم:
   `npm run dev`
5. افتح http://localhost:3000
6. جرّب `/analysis/2281` أو Team ID ديالك.

لا توجد مفاتيح API خاصة مطلوبة للتكامل العام. لا تضع أي مفاتيح سرية في كود الواجهة.
