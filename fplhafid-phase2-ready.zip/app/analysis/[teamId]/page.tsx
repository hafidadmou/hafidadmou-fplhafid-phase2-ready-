import RatingCircle from "../../../components/RatingCircle";
import { fetchBootstrap, fetchFixtures, fetchPicks, fetchTeam } from "../../../lib/fplService";
import { fixtureScoreForTeam, playerScore, teamRating } from "../../../lib/ratingService";

export const dynamic = "force-dynamic";

function posName(type: number) {
  return ({1:"حارس",2:"مدافع",3:"وسط",4:"مهاجم"} as Record<number,string>)[type] || "لاعب";
}

export default async function TeamAnalysis({ params }: { params: { teamId: string } }) {
  const id = Number(params.teamId);
  if (!Number.isInteger(id) || id <= 0) return <main className="mx-auto max-w-5xl px-5 py-12">Team ID غير صالح.</main>;

  try {
    const [team, boot, fixtures] = await Promise.all([fetchTeam(id), fetchBootstrap(), fetchFixtures()]);
    const event = team.current_event || boot.events.find((e:any)=>e.is_current)?.id || boot.events.find((e:any)=>e.is_next)?.id;
    if (!event) throw new Error("لا توجد جولة حالية");
    const picks = await fetchPicks(id, event);

    const byId = new Map(boot.elements.map((p:any)=>[p.id,p]));
    const players = (picks.picks || []).map((pick:any) => ({...byId.get(pick.element), ...pick, is_captain: pick.is_captain, is_vice: pick.is_vice_captain})).filter((p:any)=>p.id);
    const fixtureScores: Record<number,number> = {};
    for (const t of boot.teams) fixtureScores[t.id] = fixtureScoreForTeam(t.id, fixtures);
    const rating = teamRating(players, fixtureScores);
    const starters = players.filter((p:any)=>p.position <= 11 || p.multiplier > 0);
    const captain = players.find((p:any)=>p.is_captain);
    const weak = players.filter((p:any)=>playerScore(p,fixtureScores[p.team]??50)<50).sort((a:any,b:any)=>playerScore(a,fixtureScores[a.team]??50)-playerScore(b,fixtureScores[b.team]??50)).slice(0,3);

    return (
      <main className="mx-auto max-w-6xl px-5 py-8">
        <div className="mb-7">
          <p className="text-sm text-blue-600">FPLHafid • الجولة {event}</p>
          <h1 className="mt-2 text-3xl font-black">{team.name || "فريق FPL"} <span className="text-gray-400">#{id}</span></h1>
          <p className="mt-2 text-gray-500">تحليل مبني على بيانات FPL العامة المتاحة حالياً.</p>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <section className="card p-6 text-center"><h2 className="font-bold">التقييم العام</h2><div className="my-5"><RatingCircle score={rating}/></div><p className="text-sm text-gray-500">تقييم إحصائي أولي، وليس ضماناً للنقاط.</p></section>
          <section className="card p-6"><h2 className="font-bold">معلومات الفريق</h2><div className="mt-4 space-y-3 text-sm"><div className="flex justify-between"><span>المدير</span><b>{team.player_first_name} {team.player_last_name}</b></div><div className="flex justify-between"><span>النقاط الإجمالية</span><b>{team.summary_overall_points ?? "—"}</b></div><div className="flex justify-between"><span>ترتيبك</span><b>{team.summary_overall_rank?.toLocaleString() ?? "—"}</b></div><div className="flex justify-between"><span>القائد</span><b>{captain?.web_name ?? "—"}</b></div></div></section>
          <section className="card p-6"><h2 className="font-bold">أهم ملاحظة</h2><p className="mt-4 leading-7 text-gray-600">{weak.length ? `أضعف عناصر التشكيلة إحصائياً حالياً: ${weak.map((p:any)=>p.web_name).join("، ")}.` : "التشكيلة متوازنة وفق البيانات المتاحة."}</p></section>
        </div>

        <section className="card mt-6 overflow-hidden">
          <div className="border-b p-5"><h2 className="text-xl font-black">تشكيلة الجولة</h2><p className="mt-1 text-sm text-gray-500">{players.length} لاعباً • القائد: {captain?.web_name ?? "—"}</p></div>
          <div className="grid gap-3 p-4 md:grid-cols-2">
            {players.map((p:any)=> {
              const score=playerScore(p,fixtureScores[p.team]??50);
              return <div key={p.id} className="rounded-xl border p-4">
                <div className="flex items-center justify-between gap-3">
                  <div><div className="font-bold">{p.web_name} {p.is_captain && <span className="text-xs text-blue-600">©</span>}</div><div className="text-xs text-gray-500">{posName(p.element_type)} • {p.now_cost/10}م • {p.total_points} نقطة</div></div>
                  <div className="rounded-lg bg-slate-100 px-3 py-2 text-sm font-black">{score}/100</div>
                </div>
                <div className="mt-3 grid grid-cols-3 gap-2 text-xs text-gray-500"><span>الفورم: {p.form}</span><span>الدقائق: {p.minutes}</span><span>الملكية: {p.selected_by_percent}%</span></div>
              </div>
            })}
          </div>
        </section>

        <p className="mt-5 text-xs text-gray-400">تنبيه: FPLHafid مشروع مستقل وغير تابع للدوري الإنجليزي الممتاز أو Fantasy Premier League.</p>
      </main>
    );
  } catch (e) {
    return <main className="mx-auto max-w-3xl px-5 py-16"><div className="card p-8 text-center"><h1 className="text-2xl font-black">تعذر جلب بيانات الفريق</h1><p className="mt-3 text-gray-500">تأكد من Team ID واتصال الإنترنت، ثم حاول مرة أخرى.</p><a href="/" className="mt-6 inline-block rounded-xl bg-blue-600 px-5 py-3 font-bold text-white">العودة للرئيسية</a></div></main>;
  }
}
