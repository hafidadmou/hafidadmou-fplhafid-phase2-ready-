import "./globals.css";
import React from "react";

export const metadata = {
  title: "FPLHafid — محلّل تشكيلتك في الفانتازي",
  description: "تحليل تشكيلات Fantasy Premier League بالعربية.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <header className="border-b bg-white">
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
            <div className="text-xl font-black">FPL<span className="text-blue-600">Hafid</span></div>
            <div className="text-sm text-gray-500">محلّل الفانتازي بالعربية</div>
          </nav>
        </header>
        <main className="min-h-screen">{children}</main>
        <footer className="border-t bg-white">
          <div className="mx-auto max-w-6xl px-5 py-6 text-center text-xs text-gray-400">
            FPLHafid — أداة مستقلة لتحليل Fantasy Premier League
          </div>
        </footer>
      </body>
    </html>
  );
}
