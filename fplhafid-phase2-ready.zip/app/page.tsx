import Hero from "../components/Hero";

export default function Home() {
  return (
    <div className="mx-auto max-w-6xl px-5 py-10 md:py-16">
      <Hero />
    </div>
  );
}
