import TeamIdInput from "./TeamIdInput";

export default function Hero() {
  return (
    <section className="overflow-hidden rounded-3xl bg-slate-950 px-6 py-12 text-white md:px-12 md:py-16">
      <div className="max-w-3xl">
        <div className="mb-5 inline-flex rounded-full bg-white/10 px-4 py-2 text-sm">FPLHafid</div>
        <h1 className="text-4xl font-black leading-tight md:text-6xl">حلّل تشكيلتك قبل الديدلاين.</h1>
        <p className="mt-5 max-w-2xl text-lg leading-8 text-slate-300">
          أدخل Team ID ديالك وشوف تشكيلة فريقك، القائد، الدكة، والنقاط الأساسية التي تؤثر على تقييمك.
        </p>
        <div className="mt-8">
          <TeamIdInput />
        </div>
        <p className="mt-4 text-xs text-slate-400">مثال تجريبي: 2281</p>
      </div>
    </section>
  );
}
