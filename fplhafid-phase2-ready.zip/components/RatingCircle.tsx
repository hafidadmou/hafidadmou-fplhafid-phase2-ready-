export default function RatingCircle({ score }: { score: number }) {
  const pct = Math.max(0, Math.min(100, Math.round(score)));
  return (
    <div className="flex flex-col items-center">
      <div className="grid h-32 w-32 place-items-center rounded-full" style={{background:`conic-gradient(#2563eb ${pct * 3.6}deg,#e5e7eb 0deg)`}}>
        <div className="grid h-24 w-24 place-items-center rounded-full bg-white text-3xl font-black text-slate-900">{pct}</div>
      </div>
      <span className="mt-2 text-sm text-gray-500">من 100</span>
    </div>
  );
}
