"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function TeamIdInput() {
  const [teamId, setTeamId] = useState("");
  const router = useRouter();

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!/^\d{1,10}$/.test(teamId.trim())) return;
    router.push(`/analysis/${teamId.trim()}`);
  }

  return (
    <form onSubmit={submit} className="flex max-w-xl flex-col gap-3 sm:flex-row">
      <input
        value={teamId}
        onChange={(e) => setTeamId(e.target.value.replace(/\D/g, ""))}
        inputMode="numeric"
        placeholder="أدخل Team ID"
        className="min-w-0 flex-1 rounded-xl border border-white/15 bg-white px-4 py-3 text-slate-900 outline-none ring-blue-500 focus:ring-2"
      />
      <button className="rounded-xl bg-blue-600 px-6 py-3 font-bold hover:bg-blue-500">حلّل التشكيلة</button>
    </form>
  );
}
