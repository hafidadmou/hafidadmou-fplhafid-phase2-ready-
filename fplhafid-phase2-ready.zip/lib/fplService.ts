const BASE = (process.env.FPL_API_BASE || "https://fantasy.premierleague.com/api").replace(/\/$/, "");

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`, { next: { revalidate: 60 } });
  if (!res.ok) throw new Error(`FPL API ${res.status}`);
  return res.json();
}

export type Bootstrap = {
  events: any[];
  teams: any[];
  elements: any[];
  element_types: any[];
};

export async function fetchBootstrap() {
  return get<Bootstrap>("/bootstrap-static/");
}

export async function fetchTeam(teamId: number) {
  return get<any>(`/entry/${teamId}/`);
}

export async function fetchPicks(teamId: number, event: number) {
  return get<any>(`/entry/${teamId}/event/${event}/picks/`);
}

export async function fetchFixtures() {
  return get<any[]>("/fixtures/");
}
