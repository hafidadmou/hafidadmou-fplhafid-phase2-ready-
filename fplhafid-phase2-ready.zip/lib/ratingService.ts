export function clamp(n: number, min = 0, max = 100) {
  return Math.max(min, Math.min(max, n));
}

function num(v: unknown) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export function playerScore(p: any, fixtureScore: number) {
  const form = clamp(num(p.form) * 12, 0, 100);
  const points = clamp(num(p.total_points) / 2.5, 0, 100);
  const minutes = clamp(num(p.minutes) / 18, 0, 100);
  const fixtures = fixtureScore;
  const value = clamp((num(p.total_points) / Math.max(num(p.now_cost), 1)) * 10, 0, 100);
  return Math.round(form*.28 + points*.25 + minutes*.17 + fixtures*.20 + value*.10);
}

export function teamRating(players: any[], fixtureScores: Record<number, number>) {
  if (!players.length) return 0;
  const scores = players.map(p => playerScore(p, fixtureScores[p.team] ?? 50));
  return Math.round(scores.reduce((a,b)=>a+b,0) / scores.length);
}

export function fixtureScoreForTeam(teamId: number, fixtures: any[]) {
  const upcoming = fixtures.filter(f => f.finished === false && (f.team_h === teamId || f.team_a === teamId)).slice(0,5);
  if (!upcoming.length) return 50;
  const avg = upcoming.reduce((sum,f) => sum + (f.team_h === teamId ? num(f.team_h_difficulty) : num(f.team_a_difficulty)),0) / upcoming.length;
  return clamp(100 - (avg-1)*25, 0, 100);
}
